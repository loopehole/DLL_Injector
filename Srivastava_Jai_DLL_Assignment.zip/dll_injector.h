#ifndef DLL_INJECTOR_H
#define DLL_INJECTOR_H

BOOL InjectDLL(DWORD processID, const char* dllPath);

#endif // DLL_INJECTOR_H
